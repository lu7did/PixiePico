if (DEFINED ENV{PICO_SDK_PATH} AND (NOT PICO_SDK_PATH))
    set(PICO_SDK_PATH $ENV{PICO_SDK_PATH})
    message(STATUS "Using PICO_SDK_PATH from environment: ${PICO_SDK_PATH}")
endif ()

if (NOT PICO_SDK_PATH)
    message(FATAL_ERROR
        "PICO_SDK_PATH is not defined. Import/configure this folder with the "
        "official Raspberry Pi Pico VS Code extension, or pass "
        "-DPICO_SDK_PATH=C:/path/to/pico-sdk to CMake.")
endif ()

get_filename_component(PICO_SDK_PATH "${PICO_SDK_PATH}" REALPATH
                       BASE_DIR "${CMAKE_BINARY_DIR}")

if (NOT EXISTS "${PICO_SDK_PATH}/pico_sdk_init.cmake")
    message(FATAL_ERROR
        "pico_sdk_init.cmake was not found below PICO_SDK_PATH: ${PICO_SDK_PATH}")
endif ()

include("${PICO_SDK_PATH}/pico_sdk_init.cmake")
